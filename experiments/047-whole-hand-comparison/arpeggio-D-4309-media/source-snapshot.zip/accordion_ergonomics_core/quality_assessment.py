"""Versioned assessment sidecars; historical catalog identities stay unchanged."""

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from .exploration import read_hashed
from .provenance import project_source_digest
from .selection import TECHNIQUE_SOURCE


def hierarchy(realization):
    status = realization["status"]
    path = status in ("sampled_path_found", "sampled_connected_path")
    validity = realization["validity"]
    fingers = {
        c["finger"] for event in realization["events"] for c in event["contacts"]
    }
    return {
        "realization_id": realization["id"],
        "musical_target": "represented",
        "contact_pose": "discovered"
        if status
        in ("contact_candidates_found", "sampled_path_found", "sampled_connected_path")
        else "not_found",
        "connected_sampled_movement": "discovered" if path else "not_established",
        "configured_geometric_checks": validity.get(
            "independent_audit", "not_assessed"
        ),
        "anatomical_proxy_validity": validity.get(
            "anatomical_validation", "not_assessed"
        ),
        "whole_hand_posture": "not_deeply_assessed_in_045",
        "static_muscle_capacity": "not_assessed",
        "dynamic_muscle_execution": "not_evaluated",
        "human_feasibility": None,
        "ordinary_playing_recommendation": "not_established",
        "research_use": "retain_kinematic_evidence",
        "technique_234_prior": {
            "contact_sequence_compatible": fingers <= {"index", "middle", "ring"},
            "source": TECHNIQUE_SOURCE,
            "scope": (
                "Optional exploration preference; "
                "1/5 use is not invalid or universally unusual"
            ),
        },
    }


def run_quality_assessment(definition: Path, output: Path):
    raw = definition.read_bytes()
    source = json.loads(raw)
    root = definition.resolve().parents[2]
    catalog = read_hashed(root / source["catalog_result"], source["catalog_sha256"])
    audit = read_hashed(root / source["audit_result"], source["audit_sha256"])
    muscles = read_hashed(root / source["muscle_result"], source["muscle_sha256"])
    comparison = read_hashed(
        root / source["comparison_result"], source["comparison_sha256"]
    )
    media = read_hashed(
        root / source["audit_media_result"], source["audit_media_sha256"]
    )
    targets = []
    for target in catalog["targets"]:
        cases = [
            c
            for c in audit["cases"]
            if source["case_targets"][c["source_reference"]["id"]] == target["id"]
        ]
        benchmarks: list[dict[str, Any]] = []
        for c in cases:
            cid = c["source_reference"]["id"]
            static = [p for p in muscles["poses"] if p["pose"].get("case_id") == cid]
            screens = [s for p in static for s in p["static_screens"]]
            routing = next(
                (a for a in muscles["motion_derivative_audits"] if a["case_id"] == cid),
                None,
            )
            # Exact versioned records, not an inferred human verdict.
            benchmarks.append(
                dict(
                    case_id=cid,
                    source=c["source_reference"],
                    whole_hand_descriptors={
                        k: v
                        for k, v in c.items()
                        if k not in ("traces", "source_reference")
                    },
                    sampled_cross_digit_min_m=c["worst_proxy_m"],
                    strict_rigid_proxy_policy="rejected"
                    if c["worst_proxy_m"] < 0
                    else "no_overlap_found",
                    strict_policy_scope=(
                        "Reject any negative unconfigured rigid "
                        "cross-digit distance; not calibrated anatomy"
                    ),
                    first_note_approach=c["first_note_approach"],
                    static_screen_count=len(screens),
                    conditional_equilibria=sum(
                        s["conditional_feasible"] for s in screens
                    ),
                    static_muscle_capacity="attempted_conditional_balance_failed"
                    if screens
                    else "not_assessed",
                    routing_derivative_failure_samples=routing["failure_sample_indices"]
                    if routing
                    else None,
                    research_use="retain_negative_evidence"
                    if c["palm_path_m"] is None
                    else "retain_kinematic_comparison",
                    ordinary_playing_recommendation="not_established",
                    human_feasibility=None,
                )
            )
        reassessed_realizations = [hierarchy(r) for r in target["realizations"]]
        primary_hashes = {
            r["sha256"]
            for r in target.get("evidence", [])
            if r["role"] == "connected_passage_search"
        }
        for benchmark in benchmarks:
            if benchmark["source"]["search_sha256"] not in primary_hashes:
                continue
            strategy_id = benchmark["source"]["strategy_id"]
            if strategy_id is None:
                continue
            index = int(strategy_id.removeprefix("strategy-"))
            if index >= len(reassessed_realizations):
                raise ValueError("Assessment strategy does not match catalog")
            row = reassessed_realizations[index]
            row["whole_hand_posture"] = "analyzed_exact_recorded_samples"
            row["static_muscle_capacity"] = benchmark["static_muscle_capacity"]
            row["benchmark_case_id"] = benchmark["case_id"]
            row["strict_rigid_proxy_policy"] = benchmark["strict_rigid_proxy_policy"]
        targets.append(
            dict(
                target_id=target["id"],
                realizations=reassessed_realizations,
                benchmarks=benchmarks,
                discovery_status=target.get("search_status", "historical"),
                complete_movement_available=any(
                    r["status"] == "sampled_path_found" for r in target["realizations"]
                ),
                negative_evidence_retained=not bool(target["realizations"]),
                human_feasibility=None,
            )
        )
    evidence = []
    for key in ("catalog", "audit", "muscle", "comparison", "audit_media"):
        evidence.append(
            dict(role=key, path=source[key + "_result"], sha256=source[key + "_sha256"])
        )
    examples = []
    for case in media["cases"]:
        # File hashes are anchored to the numerical media record's own manifest.
        cid = case["id"]
        prefix = cid + "/"
        files = [
            dict(path=str(Path(source["audit_media_result"]).parent / k), sha256=v)
            for k, v in media["artifact_sha256"].items()
            if k.startswith(prefix) and (k.endswith("hand.png") or k.endswith(".gif"))
        ]
        examples.append(
            dict(target_id=source["case_targets"][cid], case_id=cid, files=files)
        )
    comparison_media = []
    for ref in source["comparison_media"]:
        saved_media = read_hashed(root / ref["path"], ref["sha256"])
        prefix = Path(ref["path"]).parent
        files = [
            dict(path=str(prefix / k), sha256=v)
            for k, v in saved_media["artifact_sha256"].items()
            if k.endswith("hand.png") or k.endswith(".gif")
        ]
        examples.append(
            dict(
                target_id=source["trial_targets"][ref["trial_id"]],
                trial_id=ref["trial_id"],
                files=files,
            )
        )
        comparison_media.append(ref)
    comparison_directory = Path(source["comparison_definition"]).parent
    result = dict(
        id="library-quality-048-v1",
        assessment_version="biomechanics-v1",
        input=source,
        definition_sha256=hashlib.sha256(raw).hexdigest(),
        targets=targets,
        evidence=evidence,
        comparison_trials=[
            dict(
                id=t["source"]["id"],
                target_id=source["trial_targets"][t["source"]["id"]],
                status=t["status"],
                settings=t["settings"],
                budget=t["budget"],
                source=t["source"],
                search_evidence={
                    "path": str(comparison_directory / t["source"]["search_result"]),
                    "sha256": t["source"]["search_sha256"],
                },
            )
            for t in comparison["trials"]
        ],
        visual_examples=examples,
        comparison_media=comparison_media,
        limitations=[
            "Rigid proxies uncalibrated",
            "Static scenarios lack measured support and button reactions",
            "No dynamic muscle-driven execution",
            "No validated human comfort or feasibility",
        ],
        provenance={
            "kind": "versioned_posthoc_assessment",
            "historical_catalog_sha256": source["catalog_sha256"],
            "project_source_sha256": project_source_digest(),
            "lock_sha256": hashlib.sha256(Path("uv.lock").read_bytes()).hexdigest(),
        },
    )
    output.mkdir(parents=True, exist_ok=True)
    (output / "result.json").write_text(
        json.dumps(result, separators=(",", ":"), allow_nan=False) + "\n"
    )
    metadata = output / "execution.json"
    if metadata.exists():
        execution = json.loads(metadata.read_text())
        execution["definition_reference"] = os.path.relpath(definition, output)
        metadata.write_text(json.dumps(execution, indent=2) + "\n")
    return result
