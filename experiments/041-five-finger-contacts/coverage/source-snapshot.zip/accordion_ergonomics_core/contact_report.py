"""Reproduce selected named-contact states and independently expose proxy concerns."""

import hashlib
import json
from pathlib import Path
from typing import Any

from .anatomy import DIGITS
from .collision_coverage import audit_collision_coverage
from .experiment import Experiment
from .exploration import read_hashed
from .hand_audit import audit_hand_pose
from .provenance import compiled_model_digest, current_execution_metadata
from .render import render_views
from .scene import build_scene


def run_contact_report(definition: Path, output: Path) -> dict[str, Any]:
    raw = definition.read_bytes()
    source = json.loads(raw)
    output.mkdir(parents=True, exist_ok=True)
    records = []
    for request in source["poses"]:
        saved = read_hashed(definition.parent / request["result"], request["sha256"])
        e = Experiment.from_dict(saved["input"])
        scene = build_scene(
            e.geometry,
            e.player,
            e.setup,
            e.physical_contact,
            tuple(c.finger for c in e.contacts),
        )
        if (
            compiled_model_digest(scene.model)
            != saved["provenance"]["compiled_model_sha256"]
        ):
            raise ValueError("Contact report model identity differs")
        scene.data.qpos[:] = saved["qpos_rad"]
        hand = audit_hand_pose(scene)
        coverage = audit_collision_coverage(scene)
        concerns = [
            p
            for p in hand["pairs"]
            if p["classification"] == "cross_digit_phalangeal_unresolved"
            and p["signed_proxy_distance_m"] < 0
        ]
        worst = (
            min(concerns, key=lambda p: p["signed_proxy_distance_m"])
            if concerns
            else None
        )
        roles = {
            d: "required" if any(c.finger == d for c in e.contacts) else "free"
            for d in DIGITS
        }
        cameras = (
            render_views(
                scene,
                output / "renders" / request["id"],
                saved["target"]["surface_world_m"],
                saved["target"]["button_id"],
                collision_overlay=True,
                highlighted_proxy_names=tuple(worst["geoms"]) if worst else (),
                contact_roles=roles,
                closeup=True,
            )
            if request.get("render", True)
            else {}
        )
        records.append(
            {
                "id": request["id"],
                "source": request,
                "qpos_rad": saved["qpos_rad"],
                "joint_names": saved["joint_names"],
                "contact_requirements": saved["contact_requirements"],
                "inactive_digits_policy": e.physical_contact.inactive_digits_policy,
                "solver_status": saved["status"],
                "diagnostics": saved["diagnostics"],
                "coverage": coverage,
                "hand": hand,
                "worst_cross_digit": worst,
                "cameras": cameras,
                "roles": roles,
                **current_execution_metadata(scene.model),
            }
        )
    result = {
        "id": source["id"],
        "input": source,
        "definition_sha256": hashlib.sha256(raw).hexdigest(),
        "poses": records,
        "claim": "Saved static model states; anatomy and human feasibility unresolved",
    }
    (output / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    return result
