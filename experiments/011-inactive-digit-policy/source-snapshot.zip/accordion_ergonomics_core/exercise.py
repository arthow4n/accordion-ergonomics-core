"""Select demanding realizations by discovered physical movement."""

import hashlib
import json
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any

import numpy as np

from .domain import PhysicalAction, Trajectory
from .experiment import Experiment
from .exploration import read_hashed
from .planning import PlanningSettings, audit_path
from .provenance import compiled_model_digest, project_source_digest
from .render import render_views
from .scene import build_scene


def run_exercise(definition: Path, output: Path) -> dict[str, Any]:
    raw = definition.read_bytes()
    source = json.loads(raw)
    atlas_path = definition.parent / source["atlas_result"]
    atlas = read_hashed(atlas_path, source["atlas_sha256"])
    anchor = atlas["anchor"]
    e = Experiment.from_dict(anchor["input"])
    scene = build_scene(e.geometry, e.player, e.setup, e.physical_contact)
    if (
        compiled_model_digest(scene.model)
        != anchor["provenance"]["compiled_model_sha256"]
    ):
        raise ValueError("Atlas model changed; explicitly recalculate the action space")
    profiles = e.resolved_profiles()
    profile_hash = hashlib.sha256(
        json.dumps(profiles, sort_keys=True, allow_nan=False).encode()
    ).hexdigest()
    candidates = sorted(
        (a for a in atlas["actions"] if a["best_discovered_relocation_m"] is not None),
        key=lambda a: a["best_discovered_relocation_m"],
        reverse=True,
    )
    attempts = []
    selected = None
    for action in candidates:
        evidence = read_hashed(
            atlas_path.parent / action["evidence"], action["evidence_sha256"]
        )
        realized = sorted(
            (
                p
                for p in evidence["realizations"]
                if p["trajectory"]["status"] == "sampled_path_found"
            ),
            key=lambda p: p["endpoint_relocation_m"],
        )
        for realization in realized:
            path = realization["trajectory"]
            waypoints = path.get(
                "waypoints_qpos_rad",
                [path["samples"][0]["qpos_rad"], path["samples"][-1]["qpos_rad"]],
            )
            settings = replace(
                PlanningSettings(), max_joint_step_rad=source["fine_audit_step_rad"]
            )
            audit = audit_path(scene, waypoints, e, settings)
            attempts.append(
                {
                    "button_id": action["button_id"],
                    "start_id": realization["start_id"],
                    "fine_sampled_constraints_satisfied": audit[
                        "sampled_constraints_satisfied"
                    ],
                    "maximum_penetration_m": audit["maximum_penetration_m"],
                }
            )
            if audit["sampled_constraints_satisfied"]:
                selected = (action, evidence, realization, waypoints, audit)
                break
        if selected:
            break
    output.mkdir(parents=True, exist_ok=True)
    result: dict[str, Any] = {
        "id": source["id"],
        "input": source,
        "definition_sha256": hashlib.sha256(raw).hexdigest(),
        "attempts": attempts,
        "status": "no_refined_candidate_found",
        "human_feasibility": None,
    }
    if selected:
        action, evidence, realization, waypoints, audit = selected
        state = realization["resulting_state"]
        event = PhysicalAction(
            action["button_id"],
            action["finger"],
            profile_hash,
            (anchor["target"]["button_id"],),
        )
        trajectory = Trajectory(
            tuple(anchor["joint_names"]),
            tuple(tuple(q) for q in waypoints),
            profile_hash,
            source["fine_audit_step_rad"],
        )
        result.update(
            status="sampled_model_exercise_found",
            action=asdict(event),
            trajectory=asdict(trajectory),
            audit=audit,
            endpoint_descriptors=realization["descriptors"],
            selected_endpoint_relocation_m=realization["endpoint_relocation_m"],
            selected_evidence_sha256=action["evidence_sha256"],
            selection="Largest discovered endpoint relocation; no global minimum claim",
            provenance={
                **anchor["provenance"],
                "project_source_sha256": project_source_digest(),
                "atlas_project_source_sha256": anchor["provenance"][
                    "project_source_sha256"
                ],
            },
            resolved_profiles=profiles,
            runtime=anchor["runtime"],
        )
        q = np.asarray([s["qpos_rad"] for s in audit["samples"]])
        result["joint_excursions_rad"] = {
            name: float(q[:, i].max() - q[:, i].min())
            for i, name in enumerate(anchor["joint_names"])
        }
        result["musical_events"] = [
            {
                "midi": anchor["target"]["midi"],
                "button_id": anchor["target"]["button_id"],
                "finger": "index",
                "event": "surface_contact",
            },
            {
                "midi": action["midi"],
                "button_id": action["button_id"],
                "finger": action["finger"],
                "event": "surface_contact",
            },
        ]
        target = scene.data.site(f"target_{action['button_id']}").xpos.copy()
        saved = dict(anchor)
        saved["qpos_rad"] = state["joint_angles_rad"]
        saved["input"] = json.loads(json.dumps(anchor["input"]))
        # Preserve source inputs while recording the target requirement separately.
        saved["target"] = {
            "button_id": action["button_id"],
            "midi": action["midi"],
            "surface_world_m": target.tolist(),
            "normal_world": e.geometry.rotation[:, 2].tolist(),
        }
        saved["derived_from_atlas_action"] = action["evidence_sha256"]
        (output / "endpoint.json").write_text(
            json.dumps(saved, indent=2, allow_nan=False) + "\n"
        )
        for name, index in [
            ("source", 0),
            ("middle", len(audit["samples"]) // 2),
            ("destination", len(audit["samples"]) - 1),
        ]:
            scene.data.qpos[:] = audit["samples"][index]["qpos_rad"]
            render_views(
                scene,
                output / "renders" / name,
                target.tolist(),
                action["button_id"],
                collision_overlay=True,
            )
    (output / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    return result
